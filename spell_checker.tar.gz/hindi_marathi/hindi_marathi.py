import numpy as np
import os

DEVANAGARI_START = 0x0900
size = 128

def load_words(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip()]

def build_index(words):
    n = len(words)

    counts = np.zeros((n, size), dtype=np.uint8)
    lengths = np.zeros(n, dtype=np.uint16)

    for i, w in enumerate(words):
        lengths[i] = len(w)

        for char in w:
            code = ord(char)

            if DEVANAGARI_START <= code < DEVANAGARI_START + size:
                counts[i, code - DEVANAGARI_START] += 1

    return counts, lengths

def save_index(words, counts, lengths, path):
    np.savez_compressed(path,words=np.array(words, dtype=object),counts=counts,lengths=lengths)

def load_index(path):
    data = np.load(path, allow_pickle=True)

    return (data["words"].tolist(),data["counts"],data["lengths"])

def word_counts(word):
    q = np.zeros(size, dtype=np.uint8)

    for char in word:
        code = ord(char)

        if DEVANAGARI_START <= code < DEVANAGARI_START + size:
            q[code - DEVANAGARI_START] += 1

    return q

def edit_distance(w1, w2, max_dist):
    m, n = len(w1), len(w2)

    if abs(m - n) > max_dist:
        return max_dist + 1

    prev = list(range(n + 1))

    for i in range(1, m + 1):
        curr = [i] + [0] * n

        for j in range(1, n + 1):
            cost = 0 if w1[i - 1] == w2[j - 1] else 1

            curr[j] = min(
                prev[j] + 1,
                curr[j - 1] + 1,
                prev[j - 1] + cost
            )

        if min(curr) > max_dist:
            return max_dist + 1

        prev = curr

    return prev[n]

def get_suggestions(query, words, counts, lengths, num_suggestions=20):
    query = query.strip()[:50]

    if not query:
        return []

    q_counts = word_counts(query)
    q_len = len(query)

    max_edit = max(2, int(q_len * 0.35))

    len_ok = np.abs(lengths - q_len) <= max_edit

    l1 = np.abs(counts.astype(np.int16) - q_counts.astype(np.int16)).sum(axis=1)

    mask = len_ok & (l1 <= 2 * max_edit)

    indices = np.where(mask)[0]

    if len(indices) > 1000:
        order = np.argsort(l1[indices] + np.abs(lengths[indices] - q_len))

        indices = indices[order[:1000]]

    results = []

    for idx in indices:
        w = words[idx]

        dist = edit_distance(query, w, max_edit)

        if dist <= max_edit:
            results.append((dist, w))

    results.sort()

    return [(w, d) for d, w in results[:num_suggestions]]

def correct_sentence(sentence, words, counts, lengths):
    corrected = []
    corrections = []

    for word in sentence.split():

        sugg = get_suggestions(word,words,counts,lengths,num_suggestions=3)

        if sugg and sugg[0][1] == 0:
            corrected.append(word)

        elif sugg:
            corrected.append(sugg[0][0])
            corrections.append((word, sugg))

        else:
            corrected.append(word)

    return " ".join(corrected), corrections

def main():
    txt_files = [f for f in os.listdir('.') if f.endswith('.txt')]

    print("Available files:", txt_files)

    word_file = input("Dictionary filename: ").strip()

    if not os.path.exists(word_file):
        print(f"File '{word_file}' not found!")
        return

    index_file = word_file.replace('.txt', '_index.npz')

    if os.path.exists(index_file):
        words, counts, lengths = load_index(index_file)

    else:
        words = load_words(word_file)

        counts, lengths = build_index(words)

        save_index(words, counts, lengths, index_file)


    while True:
        text = input("\nEnter word/(or 'quit'): ").strip()

        if text.lower() == "quit":
            break

        if not text:
            continue

        if len(text.split()) == 1:

            suggestions = get_suggestions(text,words,counts,lengths,num_suggestions=20)

            if not suggestions:
                print("No suggestions found.")
                continue

            for w, d in suggestions:
                print(f"{w} (distance {d})")

        else:
            corrected, corrections = correct_sentence(text,words,counts,lengths)

            for wrong, sugg in corrections:
                best_word, best_dist = sugg[0]

                print(
                    f"{wrong} -> "
                    f"{best_word} "
                    f"(distance {best_dist})"
                )

            print(corrected)

if __name__ == "__main__":
    main()
